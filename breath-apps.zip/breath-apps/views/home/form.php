<form method="POST">
	<div>
		<label>Name</label>
		<input type="text" name="name" />
	</div>
	<button type="submit">Create</button>
</form>