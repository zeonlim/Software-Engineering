<?php

namespace breath_apps\models;

use model\User;
$user = new User();
$user->setEmail('zeonlim');
$user->getEmail();


?>